package pt.ulusofona.aed.deisiRockstar2021;

public class Artista {
    String id;
    String nome;

    Artista(){
    }

    Artista(String id,String nome){
        this.id=id;
        this.nome=nome;
    }
}
